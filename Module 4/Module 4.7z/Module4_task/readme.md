1. Download starter.ps1 and main_params.json
2. Start deploy with running starter.ps1